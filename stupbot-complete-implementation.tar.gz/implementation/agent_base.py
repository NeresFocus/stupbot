"""Base Agent Class"""
import asyncio
from typing import Dict, Any, Optional
from loguru import logger
import json
import time

class BaseAgent:
    """Base class for all agents"""

    def __init__(self, agent_id: str, config: Dict[str, Any]):
        self.agent_id = agent_id
        self.config = config
        self.logic = config.get("logic", {})
        self.prompts = config.get("prompts", {})
        self.models = config.get("models", {})
        self.tools = config.get("tools", {})
        self.workflow = config.get("workflow", {})

    def execute_logic(self, user_input: Dict[str, Any]) -> str:
        """Execute decision tree logic"""
        logger.info(f"[{self.agent_id}] Executing logic...")

        decision_tree = self.logic.get("decision_tree", {})
        root = decision_tree.get("root", "analyze_input")
        nodes = decision_tree.get("nodes", {})

        current_node = root
        steps = []

        while current_node in nodes:
            node = nodes[current_node]
            steps.append(current_node)

            if "steps" in node:
                return " → ".join(steps)

            branches = node.get("branches", {})
            if branches:
                current_node = list(branches.values())[0]
            else:
                break

        logger.success(f"Logic path: {' → '.join(steps)}")
        return " → ".join(steps)

    def build_prompts(self, user_input: str) -> Dict[str, str]:
        """Build 4-layer prompt structure"""
        logger.info(f"[{self.agent_id}] Building prompts...")

        prompt_layers = self.prompts.get("prompt_layers", {})

        prompts = {
            "system": prompt_layers.get("layer_1_system", {}).get("content", ""),
            "context": "",
            "instruction": "",
            "output_format": ""
        }

        # Layer 2
        if "layer_2_context_framing" in prompt_layers:
            layer2 = prompt_layers["layer_2_context_framing"]
            if isinstance(layer2, dict) and "prompt" in layer2:
                prompts["context"] = layer2["prompt"]

        # Layer 3
        if "layer_3_analysis_prompts" in prompt_layers:
            layer3 = prompt_layers["layer_3_analysis_prompts"]
            if isinstance(layer3, dict):
                prompts["instruction"] = list(layer3.values())[0] if layer3 else ""

        # Layer 4
        if "layer_4_output_formatting" in prompt_layers:
            layer4 = prompt_layers["layer_4_output_formatting"]
            if isinstance(layer4, dict):
                prompts["output_format"] = layer4.get("template", "")

        logger.success("✓ Prompts built")
        return prompts

    async def call_llm(self, prompts: Dict[str, str], user_input: str, llm_client) -> str:
        """Call LLM with built prompts"""
        logger.info(f"[{self.agent_id}] Calling LLM...")

        full_prompt = f"{prompts['context']}\n\n{user_input}\n\n{prompts['instruction']}"

        try:
            response = await llm_client.create_message(
                system_prompt=prompts["system"],
                user_prompt=full_prompt,
                temperature=0.7,
                max_tokens=2000
            )
            logger.success("✓ LLM response received")
            return response
        except Exception as e:
            logger.error(f"LLM call failed: {e}")
            raise

    async def execute_tools(self, response: str) -> Dict[str, Any]:
        """Execute agent-specific tools"""
        logger.info(f"[{self.agent_id}] Executing tools...")

        tools_list = self.tools.get("tools", [])
        results = {}

        for tool in tools_list:
            tool_id = tool.get("id", "unknown")
            logger.info(f"  Executing {tool_id}...")
            results[tool_id] = {"status": "executed"}
            await asyncio.sleep(0.1)

        logger.success(f"✓ Executed {len(tools_list)} tools")
        return results

    async def process_workflow(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Process through workflow stages"""
        logger.info(f"[{self.agent_id}] Processing workflow...")

        pipeline = self.workflow.get("pipeline", [])
        stage_results = {}

        for stage in pipeline:
            stage_num = stage.get("stage", 0)
            stage_name = stage.get("name", "unknown")
            logger.info(f"  Stage {stage_num}: {stage_name}...")
            stage_results[stage_name] = {"completed": True}
            await asyncio.sleep(0.05)

        logger.success(f"✓ Completed {len(pipeline)} stages")
        return stage_results

    async def execute(self, user_input: Dict[str, Any], llm_client) -> Dict[str, Any]:
        """Execute complete agent workflow"""
        logger.info(f"\n{'='*80}")
        logger.info(f"🚀 {self.agent_id} WORKFLOW STARTED")
        logger.info(f"{'='*80}\n")

        start_time = time.time()

        try:
            # 1. Logic
            logic_path = self.execute_logic(user_input)

            # 2. Build prompts
            prompts = self.build_prompts(str(user_input))

            # 3. Call LLM
            llm_response = await self.call_llm(prompts, str(user_input), llm_client)

            # 4. Execute tools
            tool_results = await self.execute_tools(llm_response)

            # 5. Process workflow
            workflow_results = await self.process_workflow({
                "response": llm_response,
                "tools": tool_results
            })

            duration = time.time() - start_time

            logger.info(f"\n{'='*80}")
            logger.success(f"✅ {self.agent_id} COMPLETED IN {duration:.2f}s")
            logger.info(f"{'='*80}\n")

            return {
                "agent_id": self.agent_id,
                "logic_path": logic_path,
                "response": llm_response,
                "tools": tool_results,
                "workflow": workflow_results,
                "duration": duration,
                "status": "success"
            }

        except Exception as e:
            logger.error(f"❌ Workflow failed: {e}")
            return {
                "agent_id": self.agent_id,
                "status": "failed",
                "error": str(e)
            }
