"""LLM Configuration"""
import os
from dotenv import load_dotenv
from typing import Optional
from abc import ABC, abstractmethod
import asyncio

load_dotenv()

class LLMClient(ABC):
    """Base LLM client"""

    @abstractmethod
    async def create_message(self, system_prompt: str, user_prompt: str,
                           temperature: float = 0.7, max_tokens: int = 2000) -> str:
        pass

class MockLLMClient(LLMClient):
    """Mock LLM for testing"""

    async def create_message(self, system_prompt: str, user_prompt: str,
                           temperature: float = 0.7, max_tokens: int = 2000) -> str:
        await asyncio.sleep(0.5)  # Simulate API delay
        return """{
  "status": "simulated",
  "message": "This is a mock response from the LLM",
  "suggestions": [
    "Increase market spend",
    "Focus on product quality",
    "Build strategic partnerships"
  ]
}"""

class OpenAIClient(LLMClient):
    """OpenAI integration"""

    def __init__(self, api_key: Optional[str] = None):
        self.api_key = api_key or os.getenv("OPENAI_API_KEY")
        if not self.api_key:
            raise ValueError("OPENAI_API_KEY not set")

        try:
            import openai
            openai.api_key = self.api_key
            self.client = openai.AsyncOpenAI(api_key=self.api_key)
        except ImportError:
            raise ImportError("openai package required: pip install openai")

    async def create_message(self, system_prompt: str, user_prompt: str,
                           temperature: float = 0.7, max_tokens: int = 2000) -> str:
        try:
            response = await self.client.chat.completions.create(
                model="gpt-4",
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_prompt}
                ],
                temperature=temperature,
                max_tokens=max_tokens
            )
            return response.choices[0].message.content
        except Exception as e:
            raise RuntimeError(f"OpenAI error: {e}")

class AnthropicClient(LLMClient):
    """Anthropic (Claude) integration"""

    def __init__(self, api_key: Optional[str] = None):
        self.api_key = api_key or os.getenv("ANTHROPIC_API_KEY")
        if not self.api_key:
            raise ValueError("ANTHROPIC_API_KEY not set")

        try:
            import anthropic
            self.client = anthropic.AsyncAnthropic(api_key=self.api_key)
        except ImportError:
            raise ImportError("anthropic package required: pip install anthropic")

    async def create_message(self, system_prompt: str, user_prompt: str,
                           temperature: float = 0.7, max_tokens: int = 2000) -> str:
        try:
            response = await self.client.messages.create(
                model="claude-3-opus-20240229",
                max_tokens=max_tokens,
                system=system_prompt,
                messages=[
                    {"role": "user", "content": user_prompt}
                ]
            )
            return response.content[0].text
        except Exception as e:
            raise RuntimeError(f"Anthropic error: {e}")

def get_llm_client(provider: str = "mock") -> LLMClient:
    """Factory function to get LLM client"""
    if provider == "openai":
        return OpenAIClient()
    elif provider == "anthropic":
        return AnthropicClient()
    elif provider == "mock":
        return MockLLMClient()
    else:
        raise ValueError(f"Unknown provider: {provider}")
