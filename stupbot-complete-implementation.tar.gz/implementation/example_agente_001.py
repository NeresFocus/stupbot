"""Example: Using AGENTE_001 - STRAT_MASTER"""
import asyncio
import sys
from pathlib import Path

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent))

from agent_loader import AgentLoader
from agent_base import BaseAgent
from llm_config import get_llm_client
from loguru import logger

async def main():
    """Complete example of AGENTE_001 usage"""

    logger.info("🚀 AGENTE_001 - STRAT_MASTER Example\n")

    # 1. Load agent configuration
    logger.info("Step 1: Loading agent configuration...")
    loader = AgentLoader("agents")
    config = loader.load_agent_config("AGENTE_001")
    logger.success("✓ Configuration loaded\n")

    # 2. Create agent instance
    logger.info("Step 2: Creating agent instance...")
    agent = BaseAgent("AGENTE_001", config)
    logger.success("✓ Agent created\n")

    # 3. Prepare user input
    logger.info("Step 3: Preparing user input...")
    user_input = {
        "company_name": "TechStartup AI",
        "current_revenue": 500000,
        "growth_rate_monthly": 0.12,
        "team_size": 8,
        "key_challenges": [
            "Customer acquisition cost rising",
            "Scaling operations efficiently",
            "Attracting top engineering talent"
        ],
        "timeline": "1 year",
        "objective": "3x revenue growth"
    }
    logger.info(f"Input: {user_input}\n")

    # 4. Get LLM client
    logger.info("Step 4: Initializing LLM client...")
    try:
        llm_client = get_llm_client("openai")
        logger.success("✓ Using OpenAI\n")
    except:
        logger.warning("OpenAI not available, using mock client\n")
        llm_client = get_llm_client("mock")

    # 5. Execute agent
    logger.info("Step 5: Executing agent workflow...\n")
    result = await agent.execute(user_input, llm_client)

    # 6. Display results
    logger.info("\nStep 6: Results\n")
    if result["status"] == "success":
        logger.success("✅ Agent execution successful!\n")

        logger.info("📊 RESULTS SUMMARY:")
        logger.info(f"  Duration: {result['duration']:.2f}s")
        logger.info(f"  Logic Path: {result['logic_path']}")
        logger.info(f"  Tools Executed: {len(result['tools'])}")
        logger.info(f"  Workflow Stages: {len(result['workflow'])}")

        logger.info("\n📝 LLM RESPONSE:\n")
        logger.info(result['response'][:500] + "...")
    else:
        logger.error(f"❌ Error: {result.get('error')}")

if __name__ == "__main__":
    asyncio.run(main())
