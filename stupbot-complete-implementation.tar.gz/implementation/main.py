"""Main Entry Point"""
import asyncio
import sys
from pathlib import Path

from agent_loader import AgentLoader
from agent_base import BaseAgent
from llm_config import get_llm_client
from loguru import logger

async def run_agent(agent_id: str, user_input: dict, llm_provider: str = "mock"):
    """Run any agent"""

    # Load configuration
    loader = AgentLoader("agents")
    config = loader.load_agent_config(agent_id)

    # Create agent
    agent = BaseAgent(agent_id, config)

    # Get LLM client
    try:
        llm_client = get_llm_client(llm_provider)
    except:
        logger.warning(f"Provider {llm_provider} not available, using mock")
        llm_client = get_llm_client("mock")

    # Execute
    result = await agent.execute(user_input, llm_client)

    return result

if __name__ == "__main__":
    # Example: Run AGENTE_001
    user_input = {
        "company_name": "MyStartup",
        "revenue": 100000,
        "growth_rate": 0.15,
        "objective": "3x growth"
    }

    result = asyncio.run(run_agent("AGENTE_001", user_input))
    logger.info(f"\nResult: {result}")
