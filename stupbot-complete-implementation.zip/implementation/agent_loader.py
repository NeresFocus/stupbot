"""Agent Configuration Loader"""
import json
from pathlib import Path
from typing import Dict, Any
from loguru import logger

class AgentLoader:
    """Load agent configurations from JSON files"""

    def __init__(self, agents_dir: str = "agents"):
        self.agents_dir = Path(agents_dir)
        self.agents_cache = {}
        logger.info(f"Agent loader initialized with dir: {agents_dir}")

    def load_agent_config(self, agent_id: str) -> Dict[str, Any]:
        """Load complete agent configuration"""
        if agent_id in self.agents_cache:
            return self.agents_cache[agent_id]

        logger.info(f"Loading {agent_id}...")
        config = {}

        # Load LOGIC
        logic_file = self.agents_dir / f"{agent_id}_LOGIC.json"
        if logic_file.exists():
            with open(logic_file) as f:
                config["logic"] = json.load(f)
                logger.info(f"  ✓ Loaded logic")

        # Load PROMPTS
        prompts_file = self.agents_dir / f"{agent_id}_PROMPTS.json"
        if prompts_file.exists():
            with open(prompts_file) as f:
                config["prompts"] = json.load(f)
                logger.info(f"  ✓ Loaded prompts")

        # Load MODELS
        models_file = self.agents_dir / f"{agent_id}_MODELS.json"
        if models_file.exists():
            with open(models_file) as f:
                config["models"] = json.load(f)
                logger.info(f"  ✓ Loaded models")

        # Load TOOLS
        tools_file = self.agents_dir / f"{agent_id}_TOOLS.json"
        if tools_file.exists():
            with open(tools_file) as f:
                config["tools"] = json.load(f)
                logger.info(f"  ✓ Loaded tools")

        # Load WORKFLOW
        workflow_file = self.agents_dir / f"{agent_id}_WORKFLOW.json"
        if workflow_file.exists():
            with open(workflow_file) as f:
                config["workflow"] = json.load(f)
                logger.info(f"  ✓ Loaded workflow")

        self.agents_cache[agent_id] = config
        logger.success(f"✅ Complete configuration loaded for {agent_id}")
        return config
