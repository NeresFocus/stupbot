# 🔧 AGENT LOGIC IMPLEMENTATION GUIDE

## 📚 What You Have

A complete agent system with:
- **10 Agents** with specific logic
- **Logic flows** for decision making
- **Prompt structures** with 4 layers
- **Data models** for input/output
- **Tools** for each agent
- **Workflows** with 5-7 stages
- **Validation** rules

## 🏗️ Architecture Overview

```
Agent Input
    ↓
Logic Flow (Decision Tree)
    ↓
Prompt Structure (System → Context → Instruction → Output)
    ↓
Call Agent Tools
    ↓
Process with Workflow Pipeline
    ↓
Validate Against Rules
    ↓
Generate Output
```

## 🚀 Implementation Steps

### Step 1: Load Agent Configuration

```python
import json

def load_agent_config(agent_id):
    with open(f"agents/{agent_id}_LOGIC.json") as f:
        logic = json.load(f)

    with open(f"agents/{agent_id}_PROMPTS.json") as f:
        prompts = json.load(f)

    with open(f"agents/{agent_id}_TOOLS.json") as f:
        tools = json.load(f)

    return {
        "logic": logic,
        "prompts": prompts,
        "tools": tools
    }

# Usage
config = load_agent_config("AGENTE_001")
```

### Step 2: Validate Input Against Model

```python
from jsonschema import validate

def validate_agent_input(agent_id, user_input):
    # Load model
    with open("COMPREHENSIVE_DATA_MODELS.json") as f:
        models = json.load(f)

    model_schema = models[f"{agent_id}_MODELS"]["models"]["Input"]

    # Validate
    validate(instance=user_input, schema=model_schema)
    print("✓ Input is valid")
```

### Step 3: Execute Logic Flow

```python
def execute_agent_logic(agent_id, user_input):
    config = load_agent_config(agent_id)

    # Follow decision tree
    logic = config["logic"]
    decision_tree = logic["decision_tree"]

    # Navigate through tree based on input
    current_node = decision_tree["root"]

    while True:
        node = decision_tree["nodes"][current_node]

        # Make decision
        decision = analyze_input(user_input, node["logic"])

        # Get next branch
        next_node = node["branches"][decision]

        if "steps" in decision_tree["nodes"][next_node]:
            # End of tree - return steps
            return decision_tree["nodes"][next_node]["steps"]

        current_node = next_node
```

### Step 4: Build Prompts

```python
def build_agent_prompt(agent_id, user_input, context=None):
    config = load_agent_config(agent_id)

    prompts = config["prompts"]["prompt_layers"]

    # Layer 1: System Prompt
    system = prompts["layer_1_system"]["content"]

    # Layer 2: Context
    if "layer_2_context_framing" in prompts:
        context_prompt = prompts["layer_2_context_framing"]["prompts"][0]["prompt"]

    # Layer 3: Specific Analysis Prompts
    if "layer_3_analysis_prompts" in prompts:
        analysis = prompts["layer_3_analysis_prompts"]["prompts"]

    # Layer 4: Output Format
    output_format = prompts["layer_4_output_formatting"]["template"]

    return {
        "system": system,
        "context": context_prompt,
        "user": user_input,
        "format": output_format
    }
```

### Step 5: Call Agent

```python
async def call_agent(agent_id, user_input, llm_client):
    # Validate input
    validate_agent_input(agent_id, user_input)

    # Build prompts
    prompts = build_agent_prompt(agent_id, user_input)

    # Call LLM
    response = await llm_client.create_message(
        system_prompt=prompts["system"],
        user_prompt=f"{prompts['context']}\n\n{prompts['user']}"
    )

    return response
```

### Step 6: Process with Workflow

```python
def execute_workflow(agent_id, llm_response):
    with open("WORKFLOW_PIPELINES.json") as f:
        pipelines = json.load(f)

    pipeline = pipelines[f"{agent_id}_WORKFLOW"]["pipeline"]

    # Execute each stage
    for stage in pipeline:
        print(f"Stage {stage['stage']}: {stage['name']} ({stage['time']})")
        # Process stage data

    return llm_response
```

### Step 7: Validate Output

```python
def validate_agent_output(agent_id, response):
    with open("VALIDATION_RULES.json") as f:
        rules = json.load(f)

    agent_rules = rules.get(agent_id, {})

    # Check output validation
    for check in agent_rules.get("output_validation", []):
        if not perform_check(response, check):
            print(f"⚠️ Failed: {check}")

    # Calculate quality score
    score = calculate_quality(response, agent_rules.get("quality_score", {}))

    return {
        "valid": True,
        "score": score,
        "issues": []
    }
```

## 📊 Complete Flow

```python
async def complete_agent_flow(agent_id, user_input, llm_client):
    print(f"Starting {agent_id} workflow...")

    # 1. Validate input
    validate_agent_input(agent_id, user_input)

    # 2. Execute logic
    logic_steps = execute_agent_logic(agent_id, user_input)
    print(f"Logic: {' → '.join(logic_steps)}")

    # 3. Build prompts
    prompts = build_agent_prompt(agent_id, user_input)

    # 4. Call agent
    response = await call_agent(agent_id, user_input, llm_client)

    # 5. Execute workflow
    processed = execute_workflow(agent_id, response)

    # 6. Validate output
    validation = validate_agent_output(agent_id, processed)

    print(f"Quality Score: {validation['score']}/10")
    print("✓ Agent workflow complete!")

    return {
        "response": processed,
        "validation": validation
    }
```

## 🔨 Using Specific Agents

### AGENTE_001 (Strategy)

```python
strategy_input = {
    "company_profile": {
        "name": "MyStartup",
        "revenue": 100000,
        "growth_rate_monthly": 0.15
    },
    "strategic_input": {
        "primary_objective": "3x growth in 12 months",
        "timeline": "1 year"
    }
}

result = await complete_agent_flow("AGENTE_001", strategy_input, llm_client)
```

### AGENTE_002 (Optimization)

```python
opx_input = {
    "current_process": {
        "steps": ["Manual entry", "Validation", "Export"],
        "timeline": 480,  # minutes/month
        "cost": 1000
    },
    "optimization_type": "Speed"
}

result = await complete_agent_flow("AGENTE_002", opx_input, llm_client)
```

## 📋 File Structure

```
agents/
├── AGENTE_001_LOGIC.json           # Decision tree & heuristics
├── AGENTE_001_PROMPTS.json         # 4-layer prompt structure
├── AGENTE_001_MODELS.json          # Input/output data models
├── AGENTE_001_TOOLS.json           # Available tools
├── AGENTE_001_WORKFLOW.json        # Processing pipeline
│
├── AGENTE_002_LOGIC.json
├── AGENTE_002_PROMPTS.json
├── ...
│
├── AGENT_REGISTRY.json             # Master index
├── COMPREHENSIVE_DATA_MODELS.json  # All models
├── COMPREHENSIVE_TOOLS.json        # All tools
├── WORKFLOW_PIPELINES.json         # All workflows
├── VALIDATION_RULES.json           # Quality checks
└── IMPLEMENTATION_GUIDE.md         # This file
```

## ✅ Quality Checklist

- [ ] All 10 agents loaded
- [ ] Logic flows tested
- [ ] Prompts generating expected outputs
- [ ] Tools returning correct data
- [ ] Workflows completing all stages
- [ ] Validation passing 90%+
- [ ] Error handling in place
- [ ] Logging configured
- [ ] Monitoring set up
- [ ] Performance acceptable (<5 min per agent)

---

**Ready to implement!** 🚀
